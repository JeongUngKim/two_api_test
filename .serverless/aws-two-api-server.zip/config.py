
class Config :
    HOST = 'yhdb.ceypjcevkeoj.ap-northeast-2.rds.amazonaws.com'
    DATABASE = 'two_db'
    DB_USER = 'two_user'
    DB_PASSWORD = 'two123'
    SALT = 'dskj29jcdn12jn'

    # JWT 관련 변수 세팅
    JWT_SECRET_KEY ='twoproject'
    # 뱅킹등 토큰을 종료할 필요가 있을시에는 TRUE
    JWT_ACCESS_TOKEN_EXPIRES = False
    PROPAGATE_EXCEPTIONS = True
    
# AWS 관련키
    AWS_ACCESS_KEY_ID = 'AKIARZOBQZMGLMZYXVJW'
    
    AWS_SECERT_ACCESS_KEY = 'U6AYKqTSWaU63obUkmOxgHszPjbks7co2VPgvsgi'

    #S3 버킷
    S3_BUCKET = 'ungjk-test'
    #S3 위치
    S3_LOCATION = 'https://ungjk-test.s3.ap-northeast-2.amazonaws.com/'